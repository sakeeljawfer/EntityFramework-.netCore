﻿using System;

namespace EntityFramework
{
    class Program
    {
        static void Main(string[] args)
        {
            var context = new EmployeeContext("Data Source=DESKTOP-DELL;Initial Catalog=TimeManagement;Integrated Security=True");
            var provider = new EmployeeProvider(context);
               
            var employee = provider.Get(1);
            Console.WriteLine($"Welcome {employee.FirstName} {employee.LastName}");

            var repo = new EmployeeRepo(context);
            var employee1 = provider.Get(2);

            repo.Create("First", "Last", "Address", "12345", "67890");

            employee1.FirstName = "NewFirst";
            repo.Update(employee1);
            
            repo.Delete(employee1);

        }
    }
}
